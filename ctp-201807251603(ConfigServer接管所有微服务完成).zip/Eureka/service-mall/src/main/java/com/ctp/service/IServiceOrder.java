/*
 * module: service-mall
 * file: IServiceOrder
 * date: 18-4-13 下午4:01
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.service;

import com.ctp.model.Order;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

// 对应SERVICE-ORDER的RESTful服务
@FeignClient(name = "SERVICE-ORDER", fallback = ServiceOrderFallback.class)
public interface IServiceOrder
{
    @GetMapping("/hello")
    String hello();

    @GetMapping("/test")
    String test();

    @GetMapping("/list")
    List<Order> list();

    @GetMapping("/{orderId}")
    Order loadByOrderId(@PathVariable("orderId") String orderId);
}
