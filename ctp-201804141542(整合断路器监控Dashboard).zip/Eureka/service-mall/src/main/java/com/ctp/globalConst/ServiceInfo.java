package com.ctp.globalConst;

public class ServiceInfo
{
    public static final String
            SERVICE_CLOSE = "Service is close, please wait...",
            SERVICE_ORDER = "SERVICE-ORDER",
            SERVICE_DIGITAL_CURRENCY = "SERVICE-DIGITAL-CURRENCY";
}
