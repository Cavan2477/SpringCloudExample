package com.ctp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

/**
 * 断路器Dashboard url: http://IP:port/hystrix
 * 	此处为:
 * 		http://localhost:8081/hystrix
 * 		http://localhost:8081/hystrix.stream
 */
@EnableCircuitBreaker            	// 断路器支持
@EnableHystrixDashboard				// 断路器Dashboard
@EnableFeignClients//(basePackages = "com.ctp.**")
//@RefreshScope
@EnableDiscoveryClient
@SpringBootApplication
public class ServiceMallApplication
{
	// 新增server-config时使用
	@Autowired

	public static void main(String[] args) {
		SpringApplication.run(ServiceMallApplication.class, args);
	}
}
