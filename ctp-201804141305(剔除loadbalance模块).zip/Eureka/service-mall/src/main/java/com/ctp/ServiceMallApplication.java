package com.ctp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

//@EnableCircuitBreaker            // 启动断路器支持
@EnableFeignClients//(basePackages = "com.ctp.**")
@EnableDiscoveryClient
@SpringBootApplication
public class ServiceMallApplication
{
	public static void main(String[] args) {
		SpringApplication.run(ServiceMallApplication.class, args);
	}
}
