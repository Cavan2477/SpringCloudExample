package com.ctp.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceDigitalCurrencyController
{
    @Value("${configParam}")
    private String configParam;

    @RequestMapping("/configParam")
    public String configParam()
    {
        return this.configParam;
    }

    public String getConfigParam()
    {
        return configParam;
    }

    public void setConfigParam(String configParam)
    {
        this.configParam = configParam;
    }

    @GetMapping("/service-digital-currency")
    public ResponseEntity<String> hello()
    {
        return new ResponseEntity<>("hello service digital-currency", HttpStatus.OK);
    }
}
