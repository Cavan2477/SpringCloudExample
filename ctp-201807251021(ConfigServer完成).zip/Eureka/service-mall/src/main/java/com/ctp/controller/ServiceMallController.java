package com.ctp.controller;

import com.ctp.model.Order;
import com.ctp.service.IServiceOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ServiceMallController
{
    protected Logger logger = LoggerFactory.getLogger(ServiceMallController.class);

    @Autowired
    private IServiceOrder serviceOrder;

    @GetMapping("/service-order/test")
    public String test() {
        logger.info("Service mall calling service order:test");

        return this.serviceOrder.test();
    }

    @GetMapping(value = "/service-order/list")
    public List<Order> orderList() {
        logger.info("Service mall calling service order:orderList");

        return this.serviceOrder.list();
    }

    @GetMapping(value = "/service-order/{orderId}")
    public Order detail(@PathVariable String orderId) {
        logger.info("Service mall calling service order:detail");

        return this.serviceOrder.loadByOrderId(orderId);
    }
}
