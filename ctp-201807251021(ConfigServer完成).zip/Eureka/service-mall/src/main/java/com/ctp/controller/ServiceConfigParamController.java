/*
 * module: service-mall
 * file: ServiceConfigParamController
 * date: 18-4-16 下午6:43
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceConfigParamController
{
    @Value("${configParam}")
    private String configParam;

    @GetMapping("/configParam")
    public String configParam()
    {
        return this.configParam;
    }

    public String getConfigParam()
    {
        return configParam;
    }

    public void setConfigParam(String configParam)
    {
        this.configParam = configParam;
    }

    @GetMapping("/")
    public String home()
    {
        return "Hello service order home.";
    }

//    @GetMapping("/hello")
//    public ResponseEntity<String> hello()
//    {
//        return new ResponseEntity<>("hello service order", HttpStatus.OK);
//    }
}
