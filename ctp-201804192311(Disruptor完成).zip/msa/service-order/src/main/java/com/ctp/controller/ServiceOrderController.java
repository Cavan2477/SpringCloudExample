package com.ctp.controller;

import com.ctp.dto.OrderDTO;
import com.ctp.service.IOrderProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static com.ctp.common.OrderUrl.*;

@RestController
@RequestMapping(value = SERVICE_ORDER + VERSION)
public class ServiceOrderController
{
    @Value("${server.port}")
    private String serverPort;

    @Autowired
    private IOrderProducerService orderProducerService;

    /**
     * 委托下单
     * @param orderDTO
     * @return
     */
    @PostMapping(ORDER)
    public String order(@RequestBody OrderDTO orderDTO) {
        if (orderDTO == null)
            return "";

        orderProducerService.addOrder(orderDTO);

        // TODO deal result

        return "order success!";
    }

    @GetMapping("/hello")
    public ResponseEntity<String> Hello() {
        return new ResponseEntity<>("Hello service-order, my port is " + serverPort, HttpStatus.OK);
    }

    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return new ResponseEntity<>("Service order test. Port is " + serverPort, HttpStatus.OK);
    }

    @GetMapping(value = "/list")
    public List<OrderDTO> list() {
        return this.buildOrders();
    }

    @GetMapping(value = "/{orderId}")
    public OrderDTO detail(@PathVariable Integer orderId) {
        List<OrderDTO> listOrderDTO = this.buildOrders();

        for (OrderDTO orderDTO : listOrderDTO) {
            if (orderDTO.getOrderId() == (long)orderId)
                return orderDTO;
        }

        return null;
    }

    protected List<OrderDTO> buildOrders() {
        List<OrderDTO> listOrderDTO = new ArrayList<>();

        for (long l=1; l<10; l++) {
            OrderDTO orderDTO = new OrderDTO();

            orderDTO.setOrderId(l);

            listOrderDTO.add(orderDTO);
        }

        return listOrderDTO;
    }
}
