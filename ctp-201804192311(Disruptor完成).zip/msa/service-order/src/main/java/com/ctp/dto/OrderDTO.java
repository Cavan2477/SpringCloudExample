/*
 * module: service-order
 * file: Order
 * date: 18-4-13 上午11:21
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.dto;

import lombok.*;
import lombok.extern.log4j.Log4j;

@Data
@Log4j
@NoArgsConstructor
@AllArgsConstructor
public class OrderDTO
{
    private static final long serialVersionUID = 1L;

    private Long    orderId;            // to be delete
    private String  token;              // token
    private Integer relationId;         // 货币交易对：对应表[dc_currency_relation] 等价交换货币(btc-1)/待交换货币(eth-2)
    private String  userId;             // 用户id
    private Float   price;              // 价格：from req
    private Float   amount;             // 数量：from req
    private Integer businessType;       // 买卖类型：买-1/卖-2
    private Integer txType;             // 交易类型：市价交易/限价交易
    private Float   total;              // 总额：calc by self
    private String  des;                // 刷单/真实用户交易

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
