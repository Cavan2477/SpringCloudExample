/*
 * module: service-order
 * file: OrderVO
 * date: 18-4-19 下午3:23
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.vo;

import com.ctp.dbo.OrderDO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.log4j.Log4j;

@Data
@Log4j
@NoArgsConstructor
@AllArgsConstructor
public class OrderVO
{
    private String  ret;                // 0-成功|1-失败
    private String  msg;                // 消息提示
    private OrderDO orderDO;            //

    public OrderVO(String strRet, String strMsg) {
        ret = strRet;
        msg = strMsg;
    }

    /*public OrderVO() {
    }

    public OrderVO(String strRet, String strMsg) {
        ret = strRet;
        msg = strMsg;
    }

    public OrderVO(String strRet, String strMsg, OrderDO orderDO) {
        ret = strRet;
        msg = strMsg;
        this.orderDO = orderDO;
    }

    public String getRet() {
        return ret;
    }

    public void setRet(String ret) {
        this.ret = ret;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public OrderDO getOrderDO() {
        return orderDO;
    }

    public void setOrderDO(OrderDO orderDO) {
        this.orderDO = orderDO;
    }*/
}
