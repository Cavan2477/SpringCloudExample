/*
 * module: service-order
 * file: MatchPriceHandler
 * date: 18-4-18 下午9:32
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.event;

import com.lmax.disruptor.EventHandler;

/**
 * 3.定义事件处理的具体实现
 *  第二消费者：负责检索db中能够与该委托订单价格相吻合的数据
 */
public class MatchPriceHandler implements EventHandler<OrderEvent>
{
    @Override
    public void onEvent(OrderEvent orderEvent, long lSequence, boolean bEndOfBatch) throws Exception {
        // 1.获取当前线程id
        long lCurThreadId = Thread.currentThread().getId();

        // TODO 2.获取可撮合的订单信息

        System.out.println(String.format("Receive data from client. Thread id is %d start match order price.", lCurThreadId, orderEvent.getOrderId()));
    }
}
