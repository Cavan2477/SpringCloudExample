/*
 * module: service-order
 * file: OrderProducerServiceImpl
 * date: 18-4-19 下午8:21
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.service;

import com.ctp.dto.OrderDTO;
import com.ctp.event.Official.OrderEventProducer;
import com.ctp.event.OrderEvent;
import com.ctp.event.OrderEventFactory;
import com.ctp.event.OrderEventHandler;
import com.lmax.disruptor.*;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import lombok.Data;
import org.springframework.stereotype.Service;

import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class OrderProducerServiceImpl implements IOrderProducerService
{
    // 定义用于时间处理的线程池
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    private static final OrderEventHandler ORDER_EVENT_HANDLER = new OrderEventHandler();

    private static OrderEventFactory orderEventFactory = new OrderEventFactory();

    // RingBuffer size，it must be power of 2
    private static final int RING_BUFFER_SIZE = 1024 * 1024;

    // 定义策略模式，详见ReadMe
    private static WaitStrategy BLOCKING_WAIT = new BlockingWaitStrategy();
    private static WaitStrategy SLEEPING_WAIT = new SleepingWaitStrategy();
    private static WaitStrategy YIELDING_WAIT = new YieldingWaitStrategy();

    // 1.Construct the disruptor
    private static Disruptor<OrderEvent> disruptor = new Disruptor<>(orderEventFactory, RING_BUFFER_SIZE, EXECUTOR, ProducerType.SINGLE, YIELDING_WAIT);;

    // 4.Get the ring buffer from the Disruptor to be used for publishing.
    private static RingBuffer<OrderEvent> ringBuffer;

    private static OrderEventProducer orderEventProducer;

    static {
        // 4.Get the ring buffer from the Disruptor to be used for publishing.
        if (ringBuffer == null)
            ringBuffer = disruptor.getRingBuffer();

        if (orderEventProducer == null)
            orderEventProducer = new OrderEventProducer(ringBuffer);
    }

    /**
     * start up order producer
     * @return
     */
    @Override
    public boolean startupOrderProducer() {
        // 2.Connect the handler
        disruptor.handleEventsWith(ORDER_EVENT_HANDLER);

        // 3.Start the Disruptor, starts all threads running
        disruptor.start();

        return true;
    }

    /**
     * shutdown order producer
     */
    @Override
    public void shutdownOrderProducer() {
        if (disruptor == null)
            return;

        disruptor.shutdown();

        EXECUTOR.shutdown();
    }

    /**
     * 添加订单事件
     */
    @Override
    public void addOrder(OrderDTO orderDTO) {
        if (orderDTO == null)
            return;

        orderEventProducer.onDataWithTranslator(orderDTO);
    }
}
