/*
 * module: service-order
 * file: ServiceProducer
 * date: 18-4-18 上午9:14
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.service;

import com.ctp.event.OrderEvent;
import com.lmax.disruptor.RingBuffer;
import org.springframework.stereotype.Service;

/**
 * 4.订单生产者服务线程
 */
@Service
public class OrderProducerService// implements Runnable
{
    /*private RingBuffer<OrderEvent> ringBuffer = null;

    public OrderProducerService(RingBuffer<OrderEvent> orderEventRingBuffer) {
        this.ringBuffer = orderEventRingBuffer;
    }*/

    /**
     * 发布事件，告知消费者线程可以进行消费
     */
    /*@Override
    public void run() {
        // Publishers claim events in sequence
        long lSequence = ringBuffer.next();

        OrderEvent orderEvent = ringBuffer.get(lSequence);

        orderEvent.setOrderId(1234L);

        // Make the event available to EventProcessors
        ringBuffer.publish(lSequence);
    }*/
}
