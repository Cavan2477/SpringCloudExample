/*
 * module: service-order
 * file: LongEventHandler
 * date: 18-4-18 下午2:24
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.event;

import com.lmax.disruptor.EventHandler;
import com.lmax.disruptor.WorkHandler;

/**
 * 3.定义事件处理的具体实现
 *  第一个消费者：负责保存委托订单的所有信息到db
 */
public class OrderEventHandler implements EventHandler<OrderEvent>, WorkHandler<OrderEvent>
{
    @Override
    public void onEvent(OrderEvent orderEvent) throws Exception {
        // 1.获取当前线程id
        long lCurThreadId = Thread.currentThread().getId();

        // 2.获取委托订单信息存入数据库

        // TODO Auto-generated method stub
        System.out.println(String.format("获取委托订单信息存入数据库. Thread id %d save [orderId:%d][userId:%s] to db.", lCurThreadId, orderEvent.getOrderId(), orderEvent.getUserId()));
    }

    @Override
    public void onEvent(OrderEvent orderEvent, long lSequence, boolean bEndOfBatch) throws Exception {
        this.onEvent(orderEvent);
    }
}
