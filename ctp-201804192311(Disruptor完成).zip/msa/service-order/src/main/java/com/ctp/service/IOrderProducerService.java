/*
 * module: service-order
 * file: IOrderProducerService
 * date: 18-4-19 下午8:16
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.service;

import com.ctp.dto.OrderDTO;

public interface IOrderProducerService
{
    // 启动订单处理服务
    boolean startupOrderProducer();

    // 关闭订单处理服务
    void shutdownOrderProducer();

    // 添加订单事件
    void addOrder(OrderDTO orderDTO);
}
