/*
 * module: service-order
 * file: OrderUrl
 * date: 18-4-19 下午3:02
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.common;

public class OrderUrl
{
    public static final String
            SERVICE_ORDER = "/service-order",
            VERSION = "/0.1.0";

    public static final String ORDER = "/order";
}
