/*
 * module: service-order
 * file: TestShow
 * date: 18-4-18 下午2:22
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.event.Myself;

import com.ctp.event.OrderEvent;
import com.ctp.event.OrderEventFactory;
import com.ctp.event.OrderEventHandler;
import com.lmax.disruptor.*;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 测试
 */
public class TestShow
{
    private EventFactory<OrderEvent> eventFactory = new OrderEventFactory();

    private final OrderEventHandler orderEventHandler = new OrderEventHandler();

    // RingBuffer 大小，必须是 2 的 N 次方
    private static final int RING_BUFFER_SIZE = 1024 * 1024;

    // 定义用于时间处理的线程池
    private final ExecutorService EXECUTOR = Executors.newCachedThreadPool();

    // 定义策略模式，详见ReadMe
    private WaitStrategy BLOCKING_WAIT = new BlockingWaitStrategy();
    private WaitStrategy SLEEPING_WAIT = new SleepingWaitStrategy();
    private WaitStrategy YIELDING_WAIT = new YieldingWaitStrategy();

    public TestShow() {
        Disruptor<OrderEvent> disruptor = new Disruptor<OrderEvent>(eventFactory, RING_BUFFER_SIZE, EXECUTOR, ProducerType.SINGLE, YIELDING_WAIT);

        disruptor.handleEventsWith(orderEventHandler);

        disruptor.start();

        RingBuffer<OrderEvent> ringBuffer = disruptor.getRingBuffer();

        // 请求下一个事件序号
        long lSequence = ringBuffer.next();

        try {
            // 获取该序号对应的事件对象
            OrderEvent orderEvent = ringBuffer.get(lSequence);

            // TODO 获取通过事件传递的业务数据
            long lData = getEventData();

            //orderEvent.setOrderId(Long.toString(lData));
        } finally {
            // 发布事件
            ringBuffer.publish(lSequence);
        }

        // 关闭 disruptor，方法会堵塞，直至所有的事件都得到处理；
        disruptor.shutdown();

        // 关闭 disruptor 使用的线程池；如果需要的话，必须手动关闭， disruptor 在 shutdown 时不会自动关闭；
        EXECUTOR.shutdown();
    }

    private long getEventData() {
        return 10000;
    }
}
