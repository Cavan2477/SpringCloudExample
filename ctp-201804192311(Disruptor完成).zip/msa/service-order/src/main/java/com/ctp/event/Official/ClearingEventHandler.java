/*
 * module: service-order
 * file: ClearingEventHandler
 * date: 18-4-18 下午2:37
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.event.Official;

import com.lmax.disruptor.EventHandler;

class ObjectEvent<T>
{
    T val;

    void clear() {
        val = null;
    }
}

/**
 * 手动垃圾清理
 * @param <T>
 */
public class ClearingEventHandler<T> implements EventHandler<ObjectEvent<T>>
{
    @Override
    public void onEvent(ObjectEvent<T> event, long sequence, boolean endOfBatch) throws Exception {
        // 假如清理失败，则在RingBuffer回到最初环节时被重新覆盖，不会影响垃圾回收
        event.clear();
    }
}
