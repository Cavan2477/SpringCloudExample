package com.ctp;

import com.ctp.service.IOrderProducerService;
import com.ctp.service.OrderProducerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication
public class ServiceOrderApplication
{
	private static IOrderProducerService orderProducerService = new OrderProducerServiceImpl();

	public static void main(String[] args)
	{
		orderProducerService.startupOrderProducer();

		SpringApplication.run(ServiceOrderApplication.class, args);
	}
}
