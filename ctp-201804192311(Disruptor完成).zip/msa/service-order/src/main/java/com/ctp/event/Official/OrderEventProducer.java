/*
 * module: service-order
 * file: LongEventProducer
 * date: 18-4-18 下午2:22
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.event.Official;

import com.ctp.dto.OrderDTO;
import com.ctp.event.OrderEvent;
import com.lmax.disruptor.EventTranslatorOneArg;
import com.lmax.disruptor.RingBuffer;

import java.nio.ByteBuffer;

public class OrderEventProducer
{
    private final RingBuffer<OrderEvent> ringBuffer;

    public OrderEventProducer(RingBuffer<OrderEvent> ringBuffer) {
        this.ringBuffer = ringBuffer;
    }

    /*public void onData(ByteBuffer byteBuffer) {
        long lSequence = ringBuffer.next();

        try {
            OrderEvent orderEvent = ringBuffer.get(lSequence);

            //System.out.println("orderEvent id is %d......" + orderEvent.getOrderId());

            // 填入数据
            orderEvent.setOrderId(byteBuffer.getLong(0));
        } finally {
            ringBuffer.publish(lSequence);
        }
    }

    private static final EventTranslatorOneArg<OrderEvent, ByteBuffer> TRANSLATOR = new EventTranslatorOneArg<OrderEvent, ByteBuffer>() {
        public void translateTo(OrderEvent orderEvent, long lSequence, ByteBuffer byteBuffer) {
            orderEvent.setOrderId(byteBuffer.getLong(0));
        }
    };

    public void onDataWithTranslator(ByteBuffer byteBuffer) {
        long lCurThreadId = Thread.currentThread().getId();

        System.out.println(String.format("ringBuffer.publishEvent. Thread id %d, byte buffer are %s...", lCurThreadId, byteBuffer.toString()));

        ringBuffer.publishEvent(TRANSLATOR, byteBuffer);
    }*/

    public void onData(OrderDTO orderDTO) {
        long lSequence = ringBuffer.next();

        try {
            OrderEvent orderEvent = ringBuffer.get(lSequence);

            // 填入数据
            orderEvent.setOrderId(orderDTO.getOrderId());
            orderEvent.setUserId(orderDTO.getUserId());
        } finally {
            ringBuffer.publish(lSequence);
        }
    }

    private static final EventTranslatorOneArg<OrderEvent, OrderDTO> TRANSLATOR = new EventTranslatorOneArg<OrderEvent, OrderDTO>() {
        public void translateTo(OrderEvent orderEvent, long lSequence, OrderDTO orderDTO) {
            orderEvent.setOrderId(orderDTO.getOrderId());
            orderEvent.setUserId(orderDTO.getUserId());
        }
    };

    public void onDataWithTranslator(OrderDTO orderDTO) {
        long lCurThreadId = Thread.currentThread().getId();

        System.out.println(String.format("Receive order from client. Thread id %d save [orderId:%d][userId:%s] to db.", lCurThreadId, orderDTO.getOrderId(), orderDTO.getUserId()));

        ringBuffer.publishEvent(TRANSLATOR, orderDTO);
    }
}
