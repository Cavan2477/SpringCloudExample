/*
 * module: service-order
 * file: LongEventShow
 * date: 18-4-18 下午2:22
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.event.Official;

import com.ctp.dto.OrderDTO;
import com.ctp.event.OrderEvent;
import com.ctp.event.OrderEventFactory;
import com.ctp.event.OrderEventHandler;
import com.lmax.disruptor.RingBuffer;
import com.lmax.disruptor.YieldingWaitStrategy;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;

import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class OrderEventShow
{
    public static void testShow() throws Exception {
        Executor executor = Executors.newCachedThreadPool();

        // The factory for the event
        OrderEventFactory orderEventFactory = new OrderEventFactory();

        // Specify the size of the ring buffer, must be power of 2.
        int nBufferSize = 1024;

        // Construct the disruptor
        Disruptor<OrderEvent> disruptor = new Disruptor<>(orderEventFactory, nBufferSize, executor, ProducerType.SINGLE, new YieldingWaitStrategy());

        // Connect the handler
        disruptor.handleEventsWith(new OrderEventHandler());

        // Start the Disruptor, starts all threads running
        disruptor.start();

        // Get the ring buffer from the Disruptor to be used for publishing.
        RingBuffer<OrderEvent> ringBuffer = disruptor.getRingBuffer();

        OrderEventProducer orderEventProducer = new OrderEventProducer(ringBuffer);

        /*ByteBuffer byteBuffer = ByteBuffer.allocate(8);

        for (long l = 0; true; l++) {
            byteBuffer.putLong(0, l);

            orderEventProducer.onDataWithTranslator(byteBuffer);

            Thread.sleep(100);
        }*/

        for (long l=0; true; l++) {
            OrderDTO orderDTO = new OrderDTO();

            orderDTO.setOrderId(l);
            orderDTO.setUserId(String.format("%d", l%5));

            orderEventProducer.onDataWithTranslator(orderDTO);

            Thread.sleep(100);
        }
    }
}
