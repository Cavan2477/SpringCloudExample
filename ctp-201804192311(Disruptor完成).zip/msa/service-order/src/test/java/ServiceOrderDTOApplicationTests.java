/*
 * module: service-order
 * file: ServiceOrderApplicationTests
 * date: 18-4-18 上午10:12
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

import com.ctp.dto.OrderDTO;
import com.ctp.event.Myself.TestShow;
import com.ctp.event.Official.OrderEventShow;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static com.ctp.common.OrderUrl.ORDER;
import static com.ctp.common.OrderUrl.SERVICE_ORDER;
import static com.ctp.common.OrderUrl.VERSION;

@RunWith(SpringRunner.class)
@SpringBootConfiguration
@ContextConfiguration
@SpringBootTest(classes = TestShow.class)
public class ServiceOrderDTOApplicationTests
{
    private String serverUrl = "http://localhost:3331" + SERVICE_ORDER + VERSION;

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webAppContext;

    @Before
    public void before() {
        // 生成MockMvc对象实例
        mockMvc = MockMvcBuilders.webAppContextSetup(webAppContext).build();
    }

    @Test
    public void testLongEventShow() throws Exception {
        OrderEventShow.testShow();
    }

    @Test
    public void testOrder() throws Exception {
        String strUrl = serverUrl + ORDER;

        for (long l=0; l<1000; l++) {
            OrderDTO orderDTO = new OrderDTO();

            orderDTO.setOrderId(l);

            String json = String.format("{\"orderId\":\"%d\"}", l);

            mockMvc.perform(MockMvcRequestBuilders.post(strUrl)
                    .accept(MediaType.APPLICATION_JSON_UTF8)
                    .content(json.getBytes()))
                    .andExpect(MockMvcResultMatchers.status().isOk())
                    .andDo(MockMvcResultHandlers.print());
        }
    }
}
