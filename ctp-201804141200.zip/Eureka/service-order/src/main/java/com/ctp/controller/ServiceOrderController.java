package com.ctp.controller;

import com.ctp.model.Order;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/service-order")
public class ServiceOrderController
{
    @Value("${server.port}")
    private String serverPort;

    @GetMapping("/hello")
    public ResponseEntity<String> Hello()
    {
        return new ResponseEntity<>("Hello service-order, my port is " + serverPort, HttpStatus.OK);
    }

    @GetMapping("/test")
    public ResponseEntity<String> test() {
        return new ResponseEntity<>("Service order test ", HttpStatus.OK);
    }

    @GetMapping(value = "/list")
    public List<Order> list() {
        return this.buildOrders();
    }

    @GetMapping(value = "/{orderId}")
    public Order detail(@PathVariable String orderId) {
        List<Order> listOrder = this.buildOrders();

        for (Order order : listOrder) {
            if (order.getOrderId().equalsIgnoreCase(orderId))
                return order;
        }

        return null;
    }

    protected List<Order> buildOrders() {
        List<Order> listOrder = new ArrayList<>();

        listOrder.add(new Order("1", "description1"));
        listOrder.add(new Order("2", "description2"));
        listOrder.add(new Order("3", "description3"));

        return listOrder;
    }
}
