package com.ctp.controller;

import com.ctp.globalConst.ServiceInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

@RestController
public class ServiceMallController
{
    protected Logger logger = LoggerFactory.getLogger(ServiceMallController.class);

    //-------------------------------------------------------------------------
    // 负载均衡方式一
    @Autowired
    @Qualifier(value = "restTemplate")
    private RestTemplate restTemplate;

    @GetMapping("/service-digital-currency-ex")
    public String serviceDigitalCurrency() {
        logger.info("Service mall calling service digital currency");

        return restTemplate.getForEntity("http://SERVICE-DIGITAL-CURRENCY/service-digital-currency", String.class).getBody();
    }

    @GetMapping("/service-order/hello")
    public String serviceOrder() {
        logger.info("Service mall calling service order");

        return restTemplate.getForEntity("http://SERVICE-ORDER/service-order/hello", String.class).getBody();
    }

    //-------------------------------------------------------------------------
    // 负载均衡方式二
    @Autowired
    @Qualifier(value = "lbcRestTemplate")
    private RestTemplate lbcRestTemplate;

    @Autowired
    private LoadBalancerClient loadBalancerClient;

    @GetMapping(value = "/service-order-ex-other")
    public String helloEx() {
        ServiceInstance instance = this.loadBalancerClient.choose(ServiceInfo.SERVICE_ORDER);
        URI helloUri = URI.create(String.format("http://%s:%s/service-order", instance.getHost(), instance.getPort()));

        logger.info("Target service uri = {}. ", helloUri.toString());

        return this.lbcRestTemplate.getForEntity(helloUri, String.class).getBody();
    }

    //-------------------------------------------------------------------------
//    @Autowired
//    private com.ctp.service.IServiceOrder serviceOrder;
//
//    @GetMapping("/service-order1/test")
//    public String test() {
//        logger.info("Service mall calling service order:test");
//
//        return this.serviceOrder.test();
//    }
//
//    @GetMapping(value = "/service-order1/list")
//    public List<Order> orderList() {
//        logger.info("Service mall calling service order:orderList");
//
//        return this.serviceOrder.list();
//    }
//
//    @GetMapping(value = "/service-order1/{orderId}")
//    public Order detail(@PathVariable String orderId) {
//        logger.info("Service mall calling service order:detail");
//
//        return this.serviceOrder.loadByOrderId(orderId);
//    }
}
