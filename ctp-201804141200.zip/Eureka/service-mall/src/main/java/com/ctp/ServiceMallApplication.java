package com.ctp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

//@EnableCircuitBreaker            // 启动断路器支持
//@EnableFeignClients//(basePackages = "com.ctp.**")
@EnableDiscoveryClient
@SpringBootApplication
public class ServiceMallApplication
{
	/**
	 * RestTemplate是Spring提供的用于访问Rest服务的客户端，RestTemplate提供了多种便捷访问远程Http服务的方法，能够大大提高客户端的编写效率。
	 *
	 * 教程: https://www.jianshu.com/p/df9393755a05
	 *
	 * 方式一
	 * 标识为可被注入到任意service bean的强化型restTemplate实例，实现负载均衡
	 *
	 * 访问方式:
	 * 	RoundRobinRule: 轮询策略，Ribbon以轮询的方式选择服务器，这个是默认值。所以示例中所启动的两个服务会被循环访问;
	 * 	RandomRule: 随机选择，也就是说Ribbon会随机从服务器列表中选择一个进行访问;
	 * 	BestAvailableRule: 最大可用策略，即先过滤出故障服务器后，选择一个当前并发请求数最小的;
	 * 	WeightedResponseTimeRule: 带有加权的轮询策略，对各个服务器响应时间进行加权处理，然后在采用轮询的方式来获取相应的服务器;
	 * 	AvailabilityFilteringRule: 可用过滤策略，先过滤出故障的或并发请求大于阈值一部分服务实例，然后再以线性轮询的方式从过滤后的实例清单中选出一个;
	 * 	ZoneAvoidanceRule: 区域感知策略，先使用主过滤条件（区域负载器，选择最优区域）对所有实例过滤并返回过滤后的实例清单，依次使用次过滤条件列表中的过滤条件对主过滤条件的结果进行过滤，判断最小过滤数（默认1）和最小过滤百分比（默认0），最后对满足条件的服务器则使用RoundRobinRule(轮询方式)选择一个服务器实例。
	 *
	 * Ribbon的主要功能是为REST客户端实现负载均衡，其工作原理可以概括为下面四个步骤：
	 * 	1.Ribbon首先根据其所在Zone优先选择一个负载较少的Eureka Server;
	 * 	2.定期从Eureka Server更新并过滤服务实例列表;
	 * 	3.根据指定的负载均衡策略，从可用的服务器列表中选择一个服务实例的地址;
	 * 	4.然后通过RestClient进行服务调用。
	 *
	 * @return RestTemplate
	 */
	@Bean
	@LoadBalanced
	RestTemplate restTemplate() {
		return new RestTemplate();
	}

	/**
	 * 方式二
	 * 标识为可被注入到任意service bean的强化型restTemplate实例，实现负载均衡
	 *
	 * @return RestTemplate
	 */
	@Primary
	@Bean(value = "lbcRestTemplate")
	RestTemplate lbcRestTemplate() {
		return new RestTemplate();
	}

	public static void main(String[] args) {
		SpringApplication.run(ServiceMallApplication.class, args);
	}
}
