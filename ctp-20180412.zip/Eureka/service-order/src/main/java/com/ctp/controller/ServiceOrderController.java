package com.ctp.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceOrderController
{
    @Value("${server.port}")
    private String serverPort;

    @GetMapping("/order-service")
    public ResponseEntity<String> Hello()
    {
        return new ResponseEntity<>("Hello order service, my port is " + serverPort, HttpStatus.OK);
    }
}
