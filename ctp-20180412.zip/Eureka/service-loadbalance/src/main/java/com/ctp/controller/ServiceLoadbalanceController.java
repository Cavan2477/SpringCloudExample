package com.ctp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ServiceLoadbalanceController
{
    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/product/product-service")
    public String productService() {
        return restTemplate.getForEntity("http://PRODUCT-SERVICE/product-service", String.class).getBody();
    }

    @GetMapping("/order/order-service")
    public String orderService() {
        return restTemplate.getForEntity("http://ORDER-SERVICE/order-service", String.class).getBody();
    }
}
