/*
 * module: service-business-digitalCurrency
 * file: globalConst
 * date: 18-7-26 下午3:51
 * author: CavanLiu
 * copyright: (c) 2018 www.onechain001.com Inc. All rights reserved.
 * 注意：本内容仅限于上海旺链信息科技有限公司内部传阅，禁止外泄以及用于其他的商业目的，否则将依法追责。
 */

package com.ctp.globalConst;

public class globalConst
{
    public static final String
            VERSION = "1.0",
            SERVICE_BUSINESS_DIGITAL_CURRENCY = "service-business-digitalCurrency",
            REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY = "/" + SERVICE_BUSINESS_DIGITAL_CURRENCY,
            COMMOM_REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY = REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY + "/" + VERSION;
}
