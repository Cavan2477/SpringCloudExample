package com.ctp.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.ctp.globalConst.globalConst.*;

@RestController
@RequestMapping(COMMOM_REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY)
public class ServiceBusinessDigitalCurrencyController
{
    private final String SERVICE_NAME = "service-business-digitalCurrency";

    @Value("${server.port}")
    private String serverPort;

    @Value("${configParam}")
    private String configParam;

    @GetMapping("/configParam")
    public String configParam()
    {
        return this.configParam;
    }

    public String getConfigParam()
    {
        return configParam;
    }

    public void setConfigParam(String configParam)
    {
        this.configParam = configParam;
    }

    private String getServerPort()
    {
        return "Server port is " + serverPort;
    }

    @GetMapping("/test")
    public ResponseEntity<String> test()
    {
        return new ResponseEntity<>("test " + SERVICE_NAME + getServerPort(), HttpStatus.OK);
    }

    @GetMapping("/hello")
    public ResponseEntity<String> hello()
    {
        return new ResponseEntity<>("hello " + SERVICE_NAME + getServerPort(), HttpStatus.OK);
    }
}
