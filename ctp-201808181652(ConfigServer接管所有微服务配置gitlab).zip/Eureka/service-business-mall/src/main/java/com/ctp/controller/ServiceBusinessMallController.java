package com.ctp.controller;

import com.ctp.model.Order;
import com.ctp.service.IServiceBusinessDigitalCurrency;
import com.ctp.service.IServiceBusinessOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.ctp.globalConst.ServiceInfo.*;

@RestController
public class ServiceBusinessMallController
{
    protected Logger logger = LoggerFactory.getLogger(ServiceBusinessMallController.class);

    @Autowired
    private IServiceBusinessOrder serviceBusinessOrder;

    @Autowired
    private IServiceBusinessDigitalCurrency serviceBusinessDigitalCurrency;

    @GetMapping(REQUEST_SERVICE_BUSINESS_MALL + "/{msg}")
    public String mallTest(@PathVariable String msg)
    {
        String strMsg = "Service mall calling " + SERVICE_BUSINESS_MALL + ":" + msg;

        logger.info(strMsg);

        return strMsg;
    }

    // ------------------------------------------------------------------------
    // service-business-order
    @GetMapping(REQUEST_SERVICE_BUSINESS_ORDER + "/configParam")
    public String orderConfigParam() {
        logger.info("Service mall calling " + SERVICE_BUSINESS_ORDER + ":configParam");

        return this.serviceBusinessOrder.configParam();
    }

    @GetMapping(REQUEST_SERVICE_BUSINESS_ORDER + "/hello")
    public ResponseEntity<String> helloOrder() {
        logger.info("Service mall calling " + SERVICE_BUSINESS_ORDER + ":hello");

        return this.serviceBusinessOrder.hello();
    }

    @GetMapping(REQUEST_SERVICE_BUSINESS_ORDER + "/test")
    public ResponseEntity<String> testOrder() {
        logger.info("Service mall calling service-business-order:test");

        return this.serviceBusinessOrder.test();
    }

    @GetMapping(REQUEST_SERVICE_BUSINESS_ORDER + "/list")
    public List<Order> orderList() {
        logger.info("Service mall calling service-business-order:orderList");

        return this.serviceBusinessOrder.list();
    }

    @GetMapping(REQUEST_SERVICE_BUSINESS_ORDER + "/{orderId}")
    public Order detail(@PathVariable String orderId) {
        logger.info("Service mall calling service-business-order:detail");

        return this.serviceBusinessOrder.loadByOrderId(orderId);
    }

    // ------------------------------------------------------------------------
    // service-business-digital-currency
    @GetMapping(REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY + "/configParam")
    public String digitalCurrencyConfigParam() {
        logger.info("Service mall calling " + REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY + ":configParam");

        return this.serviceBusinessDigitalCurrency.configParam();
    }

    @GetMapping(REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY + "/test")
    public ResponseEntity<String> testDigitalCurrency() {
        logger.info("Service mall calling " + SERVICE_BUSINESS_DIGITAL_CURRENCY + ":test");

        return this.serviceBusinessDigitalCurrency.test();
    }

    @GetMapping(REQUEST_SERVICE_BUSINESS_DIGITAL_CURRENCY + "/hello")
    public ResponseEntity<String> helloDigitalCurrency() {
        logger.info("Service mall calling " + SERVICE_BUSINESS_DIGITAL_CURRENCY + ":hello");

        return this.serviceBusinessDigitalCurrency.hello();
    }
}
