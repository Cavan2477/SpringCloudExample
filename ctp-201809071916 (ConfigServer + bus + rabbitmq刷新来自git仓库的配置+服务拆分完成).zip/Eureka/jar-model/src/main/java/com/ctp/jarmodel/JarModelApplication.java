package com.ctp.jarmodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JarModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(JarModelApplication.class, args);
	}
}
