package com.ctp.globalConst;

public class ServiceInfo
{
    public static final String
            VERSION = "/1.0",
            SERVICE_CLOSE = "Service is close, please wait...",
            SERVICE_MALL = "service-mall",
            SERVICE_ORDER = "service-order",
            SERVICE_DIGITAL_CURRENCY = "service-digital-currency";

    public static final String
            REQUEST_SERVICE_MALL = "/" + SERVICE_MALL,
            REQUEST_SERVICE_ORDER = "/" + SERVICE_ORDER,
            REQUEST_SERVICE_DIGITAL_CURRENCY = "/" + SERVICE_DIGITAL_CURRENCY;

    public static final String
            REQUEST_SERVICE_ORDER_VERSION = REQUEST_SERVICE_ORDER + VERSION,
            REQUEST_SERVICE_DIGITAL_CURRENCY_VERSION = REQUEST_SERVICE_DIGITAL_CURRENCY + VERSION;
}
