package com.ctp.controller;

import com.ctp.model.Order;
import com.ctp.service.IServiceDigitalCurrency;
import com.ctp.service.IServiceOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.ctp.globalConst.ServiceInfo.*;

@RestController
public class ServiceMallController
{
    protected Logger logger = LoggerFactory.getLogger(ServiceMallController.class);

    @Autowired
    private IServiceOrder serviceOrder;

    @Autowired
    private IServiceDigitalCurrency serviceDigitalCurrency;

    @GetMapping(REQUEST_SERVICE_MALL + "/{msg}")
    public String mallTest(@PathVariable String msg)
    {
        String strMsg = "Service mall calling " + SERVICE_MALL + ":" + msg;

        logger.info(strMsg);

        return strMsg;
    }

    // ------------------------------------------------------------------------
    // service-order
    @GetMapping(REQUEST_SERVICE_ORDER + "/configParam")
    public String orderConfigParam() {
        logger.info("Service mall calling " + SERVICE_ORDER + ":configParam");

        return this.serviceOrder.configParam();
    }

    @GetMapping(REQUEST_SERVICE_ORDER + "/hello")
    public ResponseEntity<String> helloOrder() {
        logger.info("Service mall calling " + SERVICE_ORDER + ":hello");

        return this.serviceOrder.hello();
    }

    @GetMapping(REQUEST_SERVICE_ORDER + "/test")
    public ResponseEntity<String> testOrder() {
        logger.info("Service mall calling service-order:test");

        return this.serviceOrder.test();
    }

    @GetMapping(REQUEST_SERVICE_ORDER + "/list")
    public List<Order> orderList() {
        logger.info("Service mall calling service-order:orderList");

        return this.serviceOrder.list();
    }

    @GetMapping(REQUEST_SERVICE_ORDER + "/{orderId}")
    public Order detail(@PathVariable String orderId) {
        logger.info("Service mall calling service-order:detail");

        return this.serviceOrder.loadByOrderId(orderId);
    }

    // ------------------------------------------------------------------------
    // service-digital-currency
    @GetMapping(REQUEST_SERVICE_DIGITAL_CURRENCY + "/configParam")
    public String digitalCurrencyConfigParam() {
        logger.info("Service mall calling " + REQUEST_SERVICE_DIGITAL_CURRENCY + ":configParam");

        return this.serviceDigitalCurrency.configParam();
    }

    @GetMapping(REQUEST_SERVICE_DIGITAL_CURRENCY + "/test")
    public ResponseEntity<String> testDigitalCurrency() {
        logger.info("Service mall calling " + SERVICE_DIGITAL_CURRENCY + ":test");

        return this.serviceDigitalCurrency.test();
    }

    @GetMapping(REQUEST_SERVICE_DIGITAL_CURRENCY + "/hello")
    public ResponseEntity<String> helloDigitalCurrency() {
        logger.info("Service mall calling " + SERVICE_DIGITAL_CURRENCY + ":hello");

        return this.serviceDigitalCurrency.hello();
    }
}
